﻿
<?php  
  $y="";
  if(isset($_GET['message']))
  {
	  $y=$_GET['message'];
  }
  ?><!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>zCorporate Free Html5 Responsive Template</title>
	<meta name="description" content="Free Html5 Templates and Free Responsive Themes Designed by Kimmy | zerotheme.com">
	<meta name="author" content="www.zerotheme.com">
	
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
	<link rel="stylesheet" href="css/zerogrid.css">
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/responsiveslides.css" />
	<link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
	
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<script src="js/css3-mediaqueries.js"></script>
	<![endif]-->
	
	<link href='./images/favicon.ico' rel='icon' type='image/x-icon'/>
    <script src="js/jquery.min.js"></script>
	<script src="js/responsiveslides.js"></script>
	<script>
		$(function () {
		  $("#slider").responsiveSlides({
			auto: true,
			pager: false,
			nav: true,
			speed: 500,
			maxwidth: 962,
			namespace: "centered-btns"
		  });
		});
	</script>
</head>
<body>
<!--------------Header--------------->
<header>
	<div class="wrap-header zerogrid">
		<div id="logo"><a href="#"><img src="./images/log.png"/></a></div>
		<div class="social">
			<ul>
				<li><a href="#"><img src="./images/social/facebook-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/google-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/twitter-bird-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/rss-icon.png" /></a></li>
			</ul>
		</div>
		<nav>
			<div class="wrap-nav">
				<div class="menu">
					<ul>
						<li><a href="index.php">Blog</a></li>
						<li><a href="login.php">Login</a></li>
						<li class="current"><a href="register.php">Register</a></li>
					</ul>
				</div>
				
				<div class="minimenu"><div>MENU</div>
					<select onchange="location=this.value">
						<option></option>
						<option value="index.html">Home</option>
						<option value="blog.html">Blog</option>
						<option value="gallery.html">Gallery</option>
						<option value="single.html">About</option>
						<option value="contact.html">Contact</option>
					</select>
				</div>
			</div>
		</nav>
	</div>
</header>

<!--------------Content--------------->
<div class="container" style="font-family:Times New Roman;margin-left:350px;margin-top:50px">
<form  action="blogdb.php" method="post" class="col-sm-6">
<div class="well col-sm-12" >
<h1 ><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  Registration Form</b></h1>

<h3 style="color:black">If you are already Register please <a href="login.php"><b> click here</b></a></h3>
<h3> <?php echo $y; ?></h3>
<div class="well col-sm-6" style="text-align:center">
<input type="radio"  name="select" value="2" required> <b style="tetx-align:center">Student</b>
</div>
<div class="well col-sm-6" style="text-align:center">
<input type="radio" name="select" value="3" required> <b>Teacher</b>
</div>
<div class=" form-group">
<h4><b>Name :</b><input type="text" class="form-control" id="Name" name="Name" placeholder="Enter your name"></h4>
</div>
<div class="form-group">
<h4><b>Email :</b><input type="email" class="form-control"  id="Email" name="Email" placeholder="Enter your email"></h4>
</div>
<div class="form-group">
<h4><b>Password :</b><input type="password" class="form-control" id="Password"  name="Password" placeholder="Enter your password"></h4>
</div>
<div class="form-group">
<h4><b>Confirm Password :</b><input type="password" class="form-control"id="Confirm Password" name="password" placeholder="Confirm your password"></h4>
</div>
<input type="checkbox"  checked="checked">&nbsp<b>Remember me</b><br><br>
<div class="form-group">
<input type="Submit" value="Submit" name="reg1"  class="btn btn-primary active form-control" ></input>
</div>
</div>
</form>  
</div>
<!--------------Footer--------------->
<footer>
	<div class="wrap-footer zerogrid">
		<div class="row">
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>About Us</h2></div>
						<div class="content">
							<p>Free Html5 Templates created by <a href="https://www.zerotheme.com" target="_blank">Zerotheme</a>. You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>Categories</h2></div>
						<div class="content">
							<div class="tag">
								<a href="#">Iphone 5</a><a href="#">Ipad Mini</a><a href="#">Ipod Touch</a><a href="#">Macbook Air Pro</a><a href="#">Apple Store</a><a href="#">IOS7 Features</a><a href="#">Itunes</a><a href="#">Apple Support</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>Contact Us</h2></div>
						<div class="content">
							<ul>
								<li>Address : 0123 Some Street. Country</li>
								<li>Phone : 000.000.000.000</li>
								<li>Email : admin@zerotheme.com</li>
								<li>Website : www.zerotheme.com</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="copyright">
		<p>Copyright © 2013 - Designed by <a href="https://www.zerotheme.com" title="free website templates">Zerotheme</a></p>
	</div>
</footer>
</body></html>