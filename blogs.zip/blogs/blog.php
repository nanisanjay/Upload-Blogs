<?php  
  $y="";
  if(isset($_GET['message']))
  {
	  $y=$_GET['message'];
  }       
  ?>
<html>
<head>
<title>BLOG</title>
<link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
</head>
<body>
<div class="container" style="font-family:Times New Roman">
<form  action="blogdb.php" method="post" class="col-sm-12" enctype="multipart/form-data">
<div class="well col-sm-12">
<h1><b>Enter your blog content</b></h1>
<h3> <?php echo $y; ?></h3>
<div class=" form-group">
<h4><b>Name :</b><input type="text" class="form-control" id="Name" name="Name" placeholder="Enter your name"required></h4>
</div>
<div class=" form-group">
<h4><b>Heading :</b><input type="text" class="form-control" id="Name" name="Heading" placeholder="Enter your Heading" required></h4>
</div>
<div class="form-group">
<h4><b>category</b></h4>
        <select type="button" class="btn" name="Category" required>
           <option>Technology</option>
		   <option>Bussiness</option>
		   <option>Electronics</option>
		   <option>Electrical</option>
</select>
</div>

<div class="form-group">
 <h4><b>Description</b></h4><textarea type="text" class="form-control" name="Description" placeholder="Enter your Description"required></textarea>
</div>
<div class="form-group" >
       <img src="<?php echo $target_dir;?>" height="200" width="200">   
    <input type="file" name="img" class="btn btn-primary" required>
</div>
<div class="form-group">
<input type="submit" class="btn btn-primary" name="blog1" value="submit">
</div>
</form>
</div>
</body>
</html>