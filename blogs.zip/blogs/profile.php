<?php 
$E=$_SESSION['h'];
$sql="SELECT * FROM blog WHERE bemail='$E' ";
$reg=mysqli_query($con,$sql);
while($row =mysqli_fetch_array($reg))
{
	 $Name = $row['bname'];
	 $Email = $row['bemail'];
	 $Password = $row['bpassword'];
	 $img=$row['pimage'];
	 $select=$row['brole'];
}    
	  ?>
<html>
<head>
<title>profile</title>
<link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<style>
ul
{
background-color:lightcoral;
text-decoration:none;
border:1px solid black;
margin-left:50px;
padding:30px;
}
li
{
display:block;
display:inline;
margin-left:60px;
}
a
{
text-decoration:none;
color:black;
}
li a:hover
{
color:blue;   
}




#xyz
{
border-right:2px solid black;
padding:30px;
margin-left:50px;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 2px solid black;
    text-align: left;
    padding: 8px;
}
</style>
</head>
<body  style="font-family:Times New Roman">
<h1 style="text-align:center"> Profile page</h1>
<ul>
<li id="xyz"><a href="blogdb.php?blog">Post Blogs</a><li>
<li id="xyz"><a href="blogdb.php?view">View Blogs</a></li>
<li><a href="blogdb.php?profile">Profile</a></li>
<li>Logout</li>
</ul>
<h1 style="margin-left:400px;margin-top:100px">Welcome <?php echo "$Name"; ?></h1>
<div class="container col-sm-4"style="margin-top:50px;margin-left:400px;border:2px solid black;background-color:white">
<h3>
<?php
	if($select=="2")
		echo "Welcome Student" ;
	else
		echo "Welcome Teacher" ;
?>
</h3>
<form action="blogdb.php" method="POST">
 <img src="<?php echo $img;?>" height="100" width="100" style="margin-top:10px"><br>
<label>Name:-<b><?php echo "$Name"; ?></b></label><br>
<label>Email:-<b><?php echo "$Email"; ?></b></label><br>
<label>Password:-<b><?php echo "$Password"; ?></b></label><br>
<input type="submit" class="btn btn-primary" name="edit" value="EDIT">
<a href="login.php"><input type="submit" class="btn btn-primary" name="logout" value="LOGOUT"></a>

</form>
</div>
</body>
</html>