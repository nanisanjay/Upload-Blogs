<?php 
$con=mysqli_connect("localhost","root","","blogcontent");
session_start();
if(isset($_POST['reg1']))
{
$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$select=$_POST['select'];
if($Name=='' && $Email==''&& $Password=='')
{
	$msg="Registration failed";
	$mg=urlencode['$msg'];
	header("Location:http://localhost/blogs/register.php?message=$msg");
}
else
{
$sql="INSERT INTO blog(bname,bemail,bpassword,brole) VALUES ('$Name','$Email','$Password','$select')";
}
$reg=mysqli_query($con,$sql);
if($reg>0)
{
  require'login.php';
}
}
elseif(isset($_POST['login']))
{
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$_SESSION['h']=$Email;
$sql="SELECT * FROM blog WHERE bemail='$Email' and bpassword='$Password'";
$reg=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($reg))
	{
	if($row['brole']=='0')
	{
		require 'admin.php';
	}
else
{
	require'profile.php';
}
}
}
elseif(isset($_POST['edit']))
{

	require'edit.php';
}
elseif(isset($_POST['update']))
{
	 $Name = $_POST['Name'];
	 $Email = $_POST['Email'];
	 $Password = $_POST['Password'];
	$sql="UPDATE blog SET bname='$Name',bemail='$Email' ,bpassword='$Password' WHERE bemail='$Email'";
	$reg=mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($reg))
	{
	if($row['brole']=='0')
	{
		require 'admin.php';
	}
else
{
	require'profile.php';
}
}
}
else if(isset($_POST['img_upload']))
{
		$a=$_SESSION['h'];
		$target_dir = "images/";
		$target_file = $target_dir.basename($_FILES["img"]["name"]);
		$sql="UPDATE blog SET pimage='$target_file' WHERE bemail='$a'";
		mysqli_query($con,$sql);
		move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
		require'edit.php';
		
}
else if(isset($_GET['profile']))
	{
    
		require'admin.php';
	}
	else if(isset($_GET['nonverified']))
	{
		require'nonverified.php';
	}
	elseif(isset($_POST['nonverify']))
	{
		$p=$_POST['new'];
		foreach($p as $row)
		{	
		$sql="update blog SET Is_verify='1' where bid='$row'";
		$res=mysqli_query($con,$sql);
		}
				require'verified.php';
	}
	else if(isset($_GET['verified']))
	{
		require'verified.php';
	}
	elseif(isset($_POST['verify']))
	{
		$q=$_POST['new'];
		foreach($q as $row)
		{
		$sql="update blog SET Is_verify='0' where bid='$row'";
		$res=mysqli_query($con,$sql);
		}
		require 'nonverified.php';
	}
		else if(isset($_GET['nonverifiedblog']))
	{
		require'nonverifiedblog.php';
	}
	elseif(isset($_POST['nonverifyblog']))
	{
		$p=$_POST['new'];
		foreach($p as $row)
		{	
		$sql="update blog SET Is_verify='1' where bname='$row'";
		$res=mysqli_query($con,$sql);
		}
				require'verifiedblog.php';
	}
	else if(isset($_GET['verifiedblog']))
	{
		require'verifiedblog.php';
	}
	elseif(isset($_POST['verifyblog']))
	{
		$q=$_POST['new'];
		foreach($q as $row)
		{
		$sql="update blog SET Is_verify='0' where bname='$row'";
		$res=mysqli_query($con,$sql);
		}
		require 'nonverifiedblog.php';
	}
	elseif(isset($_POST['blog']))
	{
		require'contact.php';
	}
elseif(isset($_POST['blog']))
{
$Heading=$_POST['Heading'];
$Category=$_POST['Category'];
$Description=$_POST['Description'];
$target_dir = "images/";
$target_file = $target_dir.basename($_FILES["img"]["name"]);
if($Heading==''&& $Category==''&& $Description==''&& $target_dir=='')
{
     $msg="failed";
	$mg=urlencode['$msg'];
	header("Location:http://localhost/blogs/index.php?message=$msg");
}
else
{
$sql="INSERT INTO blog(bheading,bcategory,bdescription,bimage) VALUES ('$Heading','$Category','$Description','$target_file')";
$reg=mysqli_query($con,$sql);
move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
require'index.php';
}
}
elseif(isset($_GET['readmore']))
{ 
	require'about.php';
}
elseif(isset($_GET['category']))
{
	require'cate.php';
	}
	?>