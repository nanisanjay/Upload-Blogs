-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2017 at 02:19 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogcontent`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `bid` int(10) NOT NULL,
  `bname` varchar(20) NOT NULL,
  `bemail` varchar(100) NOT NULL,
  `bpassword` varchar(100) NOT NULL,
  `bheading` varchar(20) NOT NULL,
  `bcategory` varchar(20) NOT NULL,
  `pimage` varchar(500) NOT NULL,
  `bimage` varchar(400) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bdescription` mediumtext NOT NULL,
  `brole` int(30) NOT NULL,
  `Is_verify` int(30) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`bid`, `bname`, `bemail`, `bpassword`, `bheading`, `bcategory`, `pimage`, `bimage`, `Date`, `bdescription`, `brole`, `Is_verify`) VALUES
(1, 'admin', 'admin@a', '1234', '', '', 'images/550582551.jpg', '', '2017-07-05 06:05:55', '', 0, 1),
(2, 'sanjay', 'sanjay@s', '1234', '', '', 'images/black_windows_vista_logo_glass_18606_1920x1080.jpg', '', '2017-07-05 08:34:07', '', 2, 0),
(3, 'nani', 'nani@n', '1234', '', '', '', '', '2017-07-05 07:26:38', '', 3, 0),
(4, 'sir', 'sir@s', '1234', '', '', '', '', '2017-07-05 06:40:22', '', 3, 0),
(5, 'sir', 'sir@a', '1234', '', '', '', '', '2017-07-05 06:41:50', '', 3, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`bid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `bid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
