﻿<?php 
$con=mysqli_connect("localhost","root","","blogcontent");
if(isset($_GET['readmore']))
{
	$h=$_GET['readmore'];
}
$sql="SELECT * FROM blog where bid='$h' ORDER BY bid DESC";
$reg=mysqli_query($con,$sql);
 ?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>zCorporate Free Html5 Responsive Template</title>
	<meta name="description" content="Free Html5 Templates and Free Responsive Themes Designed by Kimmy | zerotheme.com">
	<meta name="author" content="www.zerotheme.com"> 
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
	<link rel="stylesheet" href="css/zerogrid.css">
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/responsiveslides.css" />
	
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<script src="js/css3-mediaqueries.js"></script>
	<![endif]-->
	
	<link href='./images/favicon.ico' rel='icon' type='image/x-icon'/>
    <script src="js/jquery.min.js"></script>
	<script src="js/responsiveslides.js"></script>
	<script>
		$(function () {
		  $("#slider").responsiveSlides({
			auto: true,
			pager: false,
			nav: true,
			speed: 500,
			maxwidth: 962,
			namespace: "centered-btns"
		  });
		});
	</script>
</head>
<body>
<!--------------Header--------------->
<header>
	<div class="wrap-header zerogrid">
		<div id="logo"><a href="#"><img src="./images/log.png"/></a></div>
		<div class="social">
			<ul>
				<li><a href="#"><img src="./images/social/facebook-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/google-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/twitter-bird-icon.png" /></a></li>
				<li><a href="#"><img src="./images/social/rss-icon.png" /></a></li>
			</ul>
		</div>
		<nav>
			<div class="wrap-nav">
				<div class="menu">
					<ul>
						<li><a href="index.php">Blog</a></li>
						<li class="current"><a href="single.html">About</a></li>
						<li><a href="contact.php">UploadBlog</a></li>
						<li><a href="login.php">Login</a></li>
						<li><a href="register.php">Register</a></li>
					</ul>
				</div>
				
				<div class="minimenu"><div>MENU</div>
					<select onchange="location=this.value">
						<option></option>
						<option value="index.html">Home</option>
						<option value="blog.html">Blog</option>
						<option value="gallery.html">Gallery</option>
						<option value="single.html">About</option>
						<option value="contact.html">Contact</option>
					</select>
				</div>
			</div>
		</nav>
	</div>
</header>

<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block05">
			<div class="title"><span>BLOG</span></div>
			<div class="col-2-3">
				<div class="wrap-col">
					<article>
					<form action="blogdb.php" method="GET">
					<?php
				while($row =mysqli_fetch_array($reg))
					{
					   echo	"<h2 style='color:blue;'>".$row['bheading']. "</h2>";
						 echo	"<div class='info'>category:".$row['bcategory']. "</div>";
						 echo	"<div >Date:".$row['Date']. "</div>";
						 echo "<div >posted by:".$row['bname']."</div>";
						 echo    '<img src= "'.$row['bimage'].'"/>';
					     echo	 "<p><b>".$row['bdescription']."</b></p>";
					}
						 ?>
						 </form>
					</article>
					
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>About Us</h2></div>
						<div class="content">
							<p>Free Html5 Templates created by <a href="https://www.zerotheme.com" target="_blank">Zerotheme</a>. You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files.</p>
						</div>
					</div>
					<div class="box">
						<div class="heading"><h2>Categories</h2></div>
						<div class="content">
							<div class="list">
								<ul>
									<li><a href="blogdb.php?category=technology">Technology</a></li>
									<li><a href="blogdb.php?category=bussiness">Bussiness</a></li>
									<li><a href="blogdb.php?category=electronics">Electronics</a></li>
									<li><a href="blogdb.php?category=electrical">Electrical</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="box">
						<div class="heading"><h2>Informations</h2></div>
						<div class="content">
							<div class="list">
								<ul>
									<li><a href="#">Magic Island Ibiza</a></li>
									<li><a href="#">Bamboo Is Just For You</a></li>
									<li><a href="#">Every Hot Summer</a></li>
									<li><a href="#">Magic Island Ibiza</a></li>
									<li><a href="#">Bamboo Is Just For You</a></li>
									<li><a href="#">Every Hot Summer</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="box">
						<div class="heading"><h2>Archive</h2></div>
						<div class="content">
							<div class="list">
								<ul>
									<li><a href="#">April 2013</a></li>
									<li><a href="#">March 2013</a></li>
									<li><a href="#">February 2013</a></li>
									<li><a href="#">January 2013</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<footer>
	<div class="wrap-footer zerogrid">
		<div class="row">
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>About Us</h2></div>
						<div class="content">
							<p>Free Html5 Templates created by <a href="https://www.zerotheme.com" target="_blank">Zerotheme</a>. You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>Categories</h2></div>
						<div class="content">
							<div class="tag">
								<a href="#">Iphone 5</a><a href="#">Ipad Mini</a><a href="#">Ipod Touch</a><a href="#">Macbook Air Pro</a><a href="#">Apple Store</a><a href="#">IOS7 Features</a><a href="#">Itunes</a><a href="#">Apple Support</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<div class="box">
						<div class="heading"><h2>Contact Us</h2></div>
						<div class="content">
							<ul>
								<li>Address : 0123 Some Street. Country</li>
								<li>Phone : 000.000.000.000</li>
								<li>Email : admin@zerotheme.com</li>
								<li>Website : www.zerotheme.com</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="copyright">
		<p>Copyright © 2013 - Designed by <a href="https://www.zerotheme.com" title="free website templates">Zerotheme</a></p>
	</div>
</footer>
</body></html>